package controlador;
//?@author T1092713

import DAO.PessoaDAO;
import model.Cliente;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.servlet.annotation.WebServlet;
import java.util.List;
    
    @WebServlet("/atualizar")
public class AtualizarServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        
        String method = request.getParameter("_method");
        
        if("put".equalsIgnoreCase(method)){
            doPut(request,response);
        }else{
          
        String nome = request.getParameter("nome");
        String tiposangue = request.getParameter("tiposangue");
        String idade = request.getParameter("idade");
        String peso = request.getParameter("peso");

        System.out.println("nome:" + nome + "Tipo Sanguineo" + tiposangue + "Idade" + idade + "Peso" + peso);

        Pessoa pessoa = new Pessoa();
        pessoa.setNome(nome);
        pessoa.setTiposangue(tiposangue);
        pessoa.setIdade(idade);
        pessoa.setPeso(peso);

        try {
            PessoaDAO.adicionarPessoa(pessoa);
        } catch (Exception e) {
            throw new ServletException(e);
        }
        response.sendRedirect("views/read.jsp");
        }
        
        
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        System.out.println("olá pessoa");
        try {
            String id = request.getParameter("id");
            System.out.println("id:" + id);

            if (id != null) {
                Pessoa pessoa = PessoaDAO.obterPessoa(Integer.parseInt(id));
                System.out.println("pessoa: "+ pessoa.getNome());
                request.setAttribute("pessoa", pessoa);
                request.getRequestDispatcher("views/update.jsp").forward(request, response);
            } else {
                List<Pessoa> pessoas = PessoaDAO.getAllPessoas();
                request.setAttribute("pessoas", pessoas);
                request.getRequestDispatcher("pessoa.jsp").forward(request, response);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    protected void doPut(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        String id = request.getParameter("id");
        String nome = request.getParameter("nome");
        String tiposangue = request.getParameter("tiposangue");
        String idade = request.getParameter("idade");
        String peso = request.getParameter("peso");

        Pessoa pessoa = new Pessoa();
        pessoa.setId(Integer.parseInt(id));
        pessoa.setNome(nome);
        pessoa.setTiposangue(tiposangue);
        pessoa.setIdade(idade);
        pessoa.setPeso(peso);

        try {
            PessoaDAO.atualizarPessoa(pessoa);
        } catch (Exception e) {
            e.printStackTrace();
        }

        response.sendRedirect("views/read.jsp");

    }

    protected void doDelete(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        String id = request.getParameter("id");

        try {
            PessoaDAO.deletarPessoa(Integer.parseInt(id));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
    
}
