package DAO;
//@author T1092713

import conexao.Conexao;
import model.Pessoa;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.sql.DriverManager;
import java.sql.SQLException;

public class PessoaDAO {
    
    public static void adicionarPessoa(Pessoa pessoa){
        String sql = = "INSERT  INTO pessoas (nome, tiposangue, idade, peso) VALUES(?, ?)";
        Connection connection = null;
        PreparedStatement pst = null;
        try{
            System.out.println("ENTROU NO DAO");
            System.out.println("CHAMOU O CONNEXCAO NULL: " + connection);
            connection = Conexao.conectar();
            System.out.println("CHAMOU O CONNEXCAO: " + connection );
            pst = connection.prepareStatement(sql);
            pst.setString(1, pessoa.getNome());
            pst.setString(2, pessoa.getTiposangue());
            pst.setString(3, pessoa.getIdade());
            pst.setString(4, pessoa.getPeso());
            pst.executeUpdate();
        }catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    public static Pessoa obterPessoa(int id) throws SQLException {
        String sql = "SELECT * FROM pessoas WHERE id = ?";
        try ( Connection conn = Conexao.conectar();  PreparedStatement pst = conn.prepareStatement(sql)) {
            pst.setInt(1, id);
            try ( ResultSet rs = pst.executeQuery()) {
                if (rs.next()) {
                    Pessoa pessoa = new Pessoa();
                    pessoa.setId(id);
                    pessoa.setNome(rs.getString("nome"));
                    pessoa.setTiposangue(rs.getString("tiposangue"));
                    System.out.println("pessoa: "+ pessoa.getNome());
                    return pessoa;
                }
            }
        }
        return null;
    }
    
    public static void atualizarPessoa(Pessoa pessoa) throws SQLException {
        String sql = "UPDATE pessoas SET nome = ?, tiposangue = ?, idade = ?, peso = ? WHERE id = ?";
        try ( Connection conn = Conexao.conectar();  PreparedStatement pst = conn.prepareStatement(sql)) {
            pst.setString(1, pessoa.getNome());
            pst.setString(2, pessoa.getTiposangue());
            pst.setString(3, pessoa.getIdade());
            pst.setString(4, pessoa.getPeso());
            pst.setInt(5, pessoa.getId());
            pst.executeUpdate();

        }
    }
    
    public static void deletarCliente(int id) throws SQLException {
        String sql = "DELETE FROM pessoas WHERE id = ?";
        try ( Connection conn = Conexao.conectar();  PreparedStatement pst = conn.prepareStatement(sql)) {
            pst.setInt(1, id);
            pst.executeUpdate();
        }
    }
    
    public static List<Pessoa> getAllPessoas() {

            List<Pessoa> pessoas = new ArrayList<>();
            String sql = "SELECT * FROM pessoas";

            try ( Connection conn = Conexao.conectar();  PreparedStatement pst = conn.prepareStatement(sql);  ResultSet rs = pst.executeQuery()) {

                while (rs.next()) {
                    Pessoa pessoa = new Pessoa();

                    pessoa.setId(rs.getInt("id"));
                    pessoa.setNome(rs.getString("nome"));
                    pessoa.setTiposangue(rs.getString("tiposangue"));
                    pessoa.setIdade(rs.getString("idade"));
                    pessoa.setPeso(rs.getString("peso"));
                    
                    pessoas.add(pessoa);
                }
            } catch (SQLException e) {
            e.printStackTrace();

        }
            return pessoas;
    }    
}
